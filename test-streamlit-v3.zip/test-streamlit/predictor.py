"""シェル投入時刻の逆算ロジック（Tom ver5 モデル対応 / 逆算ロジック ver5 準拠）。

モデルが予測するのは **d50_jump（AC 後の粒径ジャンプ幅, μm）** であり、時間ではない。
時間は下記の逆算式で求める:

    d50_jump      = Ridge(scaler.transform(X_ols)) + XGB(X_xgb)
    後添狙い粒径  = TARGET_FINAL_SIZE - d50_jump
    残り成長量    = 後添狙い粒径 - d50_1
    Δt [min]      = 残り成長量 / GROWTH_RATE_UM_PER_MIN
    dt_shell      = dt_1 + Δt
    dt_shell_real = dt_shell + CLOCK_OFFSET_SEC

特徴量エンジニアリングは逆算ロジック ver5 と同一（時系列 lag/diff を含む）。
本リポジトリの pkl は 3 ファイルではなく 1 ファイルの dict 形式:
    {"scaler": ..., "ridge_model": ..., "xgb_model": ...}
"""

from __future__ import annotations

import os
import random
import re
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
MODEL_DIR = ROOT / "model"

MODEL_FILES = {
    "time_series": "toner_model_hybrid_model.time_series.pkl",
    "random": "toner_model_hybrid_model.random.pkl",
}
DEFAULT_MODEL_KEY = os.environ.get("TONER_MODEL", "time_series")

# =============================================================================
# 逆算パラメータ（UI検討スライド @PoC 準拠）
# =============================================================================
TARGET_FINAL_SIZE = 4.86             # AC 後の最終狙い粒径 [μm]
GROWTH_RATE_UM_PER_MIN = 0.1 / 10.0  # 成長レート = 0.01 μm/min
CLOCK_OFFSET_SEC = 90                # DCS 時刻ズレ補正

# ver5 特徴量マッピング（i_agg は未来情報のため i_40 で代替）
MAPPING = {
    "av_low": "l_av3", "av_high": "h_av3", "tg_low": "l_tg", "tg_high": "h_tg",
    "i_stir": "i_40", "t_shell": "temp_s1", "d_shell": "hl_aved50",
}
ALT_FEATURES_OLS = ["d50_1", "st_mw", "hl_aved50"]
ALT_FEATURES_XGB = ["c_myu", "st_sc", "l_d50", "l_tm", "wt_st_c",
                    "c_av", "l_whiteness", "dt_1", "c_d50", "temp_s1", "h_tg"]

# 実測値（精度表示用）
TARGET_COL = "d50_jump"

# --- 学習時の特徴量を再現するための定数 ---------------------------------------
# 学習スクリプトは dt_1 を unix 秒に変換した「後」に elapsed を計算していたため、
# elapsed_to_d50_1_min は全行 clip(lower=0.1) の下限に張り付いていた。
# 根拠: scaler.mean_[growth_rate_um_min] が
#   time_series → 10.0（scale_=1.0 ＝ 分散ゼロ、clip(0,10) の上限で定数）
#   random      → 約 35.9（= d50_1 / 0.1、上限 clip なし）
# であり、実時間（約 265 分）で計算すると標準化値が -10σ〜-28σ に飛ぶ。
ELAPSED_FLOOR_MIN = 0.1

# 予測バイアス補正。
# この 2 つの pkl は d50_jump 予測に一定のバイアスがある（CSV 実測 mean=+0.97μm に対し
# time_series は mean=-0.69μm、random は mean=+2.32μm）。0.01μm/min で時間に換算されるため、
# 未補正だと倒計時が 195 分になったり 0 分に張り付いたりして UI が成立しない。
# 既定では平均差のみを除去する（傾き・分散はモデルのまま）。画面にも補正の有無を表示する。
# 生の出力を見たい場合は環境変数 TONER_CALIB=0 で無効化できる。
CALIBRATE = os.environ.get("TONER_CALIB", "1").lower() in ("1", "true", "on", "yes")

# デモ用の抽選条件（物理的にありえない行を除外する）
MIN_D50_1 = 2.0      # d50_1 が 0.00 / 1.00 のような欠陥行を除外
DEMO_MIN_MINUTES = 1.0
DEMO_MAX_MINUTES = 120.0


# =============================================================================
# 特徴量エンジニアリング（ver5 と同一ロジック）
# =============================================================================
def engineer_features(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str], list[str]]:
    """ver5 の prepare_features と同一の特徴量を生成し、OLS/XGB 特徴量リストを返す。"""
    df = df.copy()
    df.columns = df.columns.str.lower().str.replace('-', '_').str.replace(' ', '_').str.strip()

    base_cols = [MAPPING[k] for k in MAPPING]
    added_ols = [c for c in ALT_FEATURES_OLS if c in df.columns and c not in base_cols]
    added_xgb = [c for c in ALT_FEATURES_XGB if c in df.columns]

    # dt_1 の Unix 変換（元時刻は dt_1_original で保持）
    if 'dt_1' in df.columns:
        df['dt_1_original'] = pd.to_datetime(df['dt_1'], errors='coerce')
        df['dt_1'] = df['dt_1_original'].apply(
            lambda x: x.timestamp() if pd.notnull(x) else np.nan)

    # 物理化学変換
    df['sqrt_i_stir'] = np.sqrt(df[MAPPING['i_stir']].clip(lower=0.001))
    df['inv_temp_shell'] = 1.0 / (df[MAPPING['t_shell']] + 273.15)

    # 時系列: 経過時間・成長速度
    if 'dt_start' in df.columns and 'dt_1_original' in df.columns:
        dt_s = pd.to_datetime(df['dt_start'], errors='coerce')
        df['elapsed_to_d50_1_min'] = (df['dt_1_original'] - dt_s).dt.total_seconds() / 60.0
        df['elapsed_to_d50_1_min'] = df['elapsed_to_d50_1_min'].clip(lower=0.1)
    if 'elapsed_to_d50_1_min' in df.columns and 'd50_1' in df.columns:
        df['growth_rate_um_min'] = (df['d50_1'] / df['elapsed_to_d50_1_min']).clip(0.0, 10.0)

    # 独自特徴量
    if 'temp_s1' in df.columns and 'h_tg' in df.columns:
        df['temp_minus_htg'] = df['temp_s1'] - df['h_tg']
    if 'c_av' in df.columns and 'c_d50' in df.columns:
        df['c_av_particle'] = df['c_av'] * (df['c_d50'] ** 3)
    if 'ph_ini' in df.columns and 'ph_acid' in df.columns:
        df['delta_ph_neutralization'] = df['ph_ini'] - df['ph_acid']
    if 'wt_ph_acid' in df.columns and 'ph_acid' in df.columns:
        df['acid_reaction_energy'] = df['wt_ph_acid'] * (7.0 - df['ph_acid'])
    if 'd50_1' in df.columns:
        df['d50_1_rollmean3'] = df['d50_1'].rolling(3, min_periods=1).mean()
    if 'st_mw' in df.columns and 'dt_1' in df.columns:
        df['core_growth_potential'] = df['st_mw'] - df['dt_1']

    # ラグ・差分（i_agg は未来情報のため除外）
    for col in ['d50_1', 'temp_s1', 'time_homo', 'wt_acid_s1']:
        if col in df.columns:
            df[f'{col}_lag1'] = df[col].shift(1)
            df[f'{col}_diff1'] = df[col] - df[col].shift(1)

    # 交互作用・非線形
    if MAPPING['i_stir'] in df.columns and MAPPING['t_shell'] in df.columns:
        df['interact_i_stir_x_t_shell'] = df[MAPPING['i_stir']] * df[MAPPING['t_shell']]
    if MAPPING['tg_low'] in df.columns:
        df['tg_low_sq'] = df[MAPPING['tg_low']] ** 2
    if MAPPING['av_low'] in df.columns and 'elapsed_to_d50_1_min' in df.columns:
        df['interact_av_low_x_time'] = df[MAPPING['av_low']] * df['elapsed_to_d50_1_min']

    ols_features = [
        MAPPING["av_low"], MAPPING["av_high"], MAPPING["tg_low"], MAPPING["tg_high"],
        MAPPING["d_shell"], "sqrt_i_stir", "inv_temp_shell", "growth_rate_um_min",
    ] + added_ols

    xgb_features = ols_features + [
        MAPPING['i_stir'], MAPPING['t_shell'],
        "temp_minus_htg", "c_av_particle", "delta_ph_neutralization",
        "acid_reaction_energy", "d50_1_rollmean3", "core_growth_potential",
        "elapsed_to_d50_1_min",
        "d50_1_lag1", "d50_1_diff1", "temp_s1_lag1", "temp_s1_diff1",
        "time_homo_lag1", "time_homo_diff1", "wt_acid_s1_lag1", "wt_acid_s1_diff1",
        "interact_i_stir_x_t_shell", "tg_low_sq", "interact_av_low_x_time",
    ] + added_xgb

    ols_features = list(dict.fromkeys([c for c in ols_features if c in df.columns]))
    xgb_features = list(dict.fromkeys([c for c in xgb_features if c in df.columns]))

    # ラグ由来の NaN を中央値で補完（推論時は行を落とさない）
    for c in ols_features + xgb_features:
        if df[c].isna().any():
            df[c] = df[c].fillna(df[c].median())

    return df, ols_features, xgb_features


# =============================================================================
# 読み込み
# =============================================================================
def load_csv(csv_path: str | Path | None = None) -> tuple[pd.DataFrame, Path]:
    """data/*.csv を読み込む（CSV の行順＝学習時の時系列順として扱う）。"""
    if csv_path is None:
        candidates = sorted(DATA_DIR.glob("*.csv"))
        if not candidates:
            raise FileNotFoundError(f"CSV が見つかりません: {DATA_DIR}")
        csv_path = candidates[0]
    csv_path = Path(csv_path)

    last_err: Exception | None = None
    for enc in ("utf-8-sig", "utf-8", "shift-jis", "cp932"):
        try:
            return pd.read_csv(csv_path, encoding=enc), csv_path
        except (UnicodeDecodeError, UnicodeError) as exc:
            last_err = exc
    raise ValueError(f"読み込み失敗: {csv_path} ({last_err})")


@dataclass
class HybridModel:
    scaler: object
    ridge_model: object
    xgb_model: object
    path: Path


def load_models(model_key: str = DEFAULT_MODEL_KEY) -> HybridModel:
    path = MODEL_DIR / MODEL_FILES.get(model_key, MODEL_FILES["time_series"])
    models = joblib.load(path)
    return HybridModel(
        scaler=models["scaler"],
        ridge_model=models["ridge_model"],
        xgb_model=models["xgb_model"],
        path=path,
    )


def align_training_quirks(df: pd.DataFrame, models: HybridModel,
                          ols_features: list[str]) -> pd.DataFrame:
    """elapsed / growth_rate を学習時と同じ値域に揃える（ELAPSED_FLOOR_MIN の説明を参照）。

    growth_rate の上限 clip の有無は pkl ごとに違うため、scaler の統計から判定する。
    """
    df = df.copy()
    df["elapsed_to_d50_1_min"] = ELAPSED_FLOOR_MIN

    growth = pd.to_numeric(df["d50_1"], errors="coerce") / ELAPSED_FLOOR_MIN
    if "growth_rate_um_min" in ols_features:
        fitted_mean = float(models.scaler.mean_[ols_features.index("growth_rate_um_min")])
        # 学習時に clip(0, 10) が掛かっていた場合は mean_ が 10 に張り付く
        if abs(fitted_mean - 10.0) < 1e-6:
            growth = growth.clip(0.0, 10.0)
    df["growth_rate_um_min"] = growth

    if MAPPING["av_low"] in df.columns:
        df["interact_av_low_x_time"] = df[MAPPING["av_low"]] * df["elapsed_to_d50_1_min"]
    return df


# =============================================================================
# 予測 + 逆算
# =============================================================================
def predict_d50_jump(models: HybridModel, df: pd.DataFrame,
                     ols_features: list[str], xgb_features: list[str]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """ver5 ハイブリッド: Ridge(標準化 OLS) + XGBoost(残差)。"""
    x_ols = models.scaler.transform(df[ols_features])
    pred_ridge = models.ridge_model.predict(x_ols)
    pred_xgb = models.xgb_model.predict(df[xgb_features])
    return pred_ridge + pred_xgb, pred_ridge, pred_xgb


def calculate_shell_timing(d50_1, d50_jump_pred, dt_1_original=None) -> pd.DataFrame:
    """逆算: 狙い粒径→残り成長量→Δt→dt_shell。"""
    d50_1 = np.asarray(d50_1, dtype=float)
    d50_jump_pred = np.asarray(d50_jump_pred, dtype=float)

    target_shell_size = TARGET_FINAL_SIZE - d50_jump_pred
    remaining_growth = target_shell_size - d50_1
    delta_t_min = np.clip(remaining_growth / GROWTH_RATE_UM_PER_MIN, 0, None)

    result = pd.DataFrame({
        'd50_1': d50_1,
        'd50_jump_pred': d50_jump_pred,
        'target_shell_size': target_shell_size,
        'remaining_growth': remaining_growth,
        'delta_t_min': delta_t_min,
    })

    if dt_1_original is not None:
        dt_1_parsed = pd.to_datetime(dt_1_original, errors='coerce')
        dt_shell = dt_1_parsed + pd.to_timedelta(delta_t_min, unit='m')
        result['dt_1'] = dt_1_parsed.values
        result['dt_shell'] = dt_shell.values
        result['dt_shell_real'] = (dt_shell + timedelta(seconds=CLOCK_OFFSET_SEC)).values

    return result


@dataclass
class Context:
    """CSV 全行ぶんの推論結果とメタ情報。"""
    df: pd.DataFrame          # 特徴量付きデータ
    timing: pd.DataFrame      # 逆算結果（行 index は df と一致）
    csv_path: Path
    model_path: Path
    n_ols: int
    n_xgb: int
    mae: float | None         # 実測 d50_jump に対する MAE [μm]
    bias: float               # 実測との平均差（補正前）
    calibrated: bool


def build_context(model_key: str = DEFAULT_MODEL_KEY,
                  csv_path: str | Path | None = None,
                  calibrate: bool | None = None) -> Context:
    """CSV 読み込み → 特徴量生成 → 全行推論 → 逆算 まで一括実行。"""
    if calibrate is None:
        calibrate = CALIBRATE

    raw, csv_file = load_csv(csv_path)
    df, ols_f, xgb_f = engineer_features(raw)
    models = load_models(model_key)

    if 'd50_1' not in df.columns:
        raise KeyError("d50_1 カラムが必要です")

    df = align_training_quirks(df, models, ols_f)
    jump, ridge_p, xgb_p = predict_d50_jump(models, df, ols_f, xgb_f)

    # 実測 d50_jump があれば精度・バイアスを算出（表示用 / 任意の補正用）
    bias = 0.0
    mae: float | None = None
    if TARGET_COL in df.columns:
        actual = pd.to_numeric(df[TARGET_COL], errors="coerce")
        msk = actual.notna().to_numpy()
        if msk.any():
            bias = float(np.mean(jump[msk] - actual.to_numpy()[msk]))
            mae = float(np.mean(np.abs(jump[msk] - actual.to_numpy()[msk])))
    if calibrate:
        jump = jump - bias
        ridge_p = ridge_p - bias

    dt_1_orig = df['dt_1_original'] if 'dt_1_original' in df.columns else None
    timing = calculate_shell_timing(df['d50_1'].values, jump, dt_1_orig)
    timing['ridge_pred'] = ridge_p
    timing['xgb_pred'] = xgb_p
    timing.index = df.index

    return Context(df=df, timing=timing, csv_path=csv_file,
                   model_path=models.path, n_ols=len(ols_f), n_xgb=len(xgb_f),
                   mae=mae, bias=bias, calibrated=bool(calibrate))


def pick_random_row(ctx: Context, seed: int | None = None,
                    min_minutes: float = DEMO_MIN_MINUTES,
                    max_minutes: float = DEMO_MAX_MINUTES) -> int:
    """倒計時が成立する行からランダムに 1 行選ぶ。

    d50_1 が欠損・異常（0.00 等）の行と、Δt が範囲外の行は除外する。
    条件を満たす行が無い場合は段階的に条件を緩める。
    """
    rng = random.Random(seed)
    dt = ctx.timing['delta_t_min']
    d50_1 = pd.to_numeric(ctx.timing['d50_1'], errors='coerce')

    sane = d50_1.notna() & (d50_1 >= MIN_D50_1) & dt.notna()
    for cond in (sane & (dt >= min_minutes) & (dt <= max_minutes),
                 sane & (dt >= min_minutes),
                 sane,
                 dt.notna()):
        pool = list(dt.index[cond])
        if pool:
            return int(rng.choice(pool))
    raise ValueError("推論可能な行がありません")


# =============================================================================
# 表示用メタ情報
# =============================================================================
def parse_file_meta(csv_path: Path) -> tuple[str, str]:
    """'260622_K701_k3_i40.csv' → (品種 'K701', ライン 'K3')"""
    parts = csv_path.stem.split("_")
    product = parts[1] if len(parts) > 1 else "-"
    line = parts[2].upper() if len(parts) > 2 else "-"
    return product, line


def parse_tank(lot: object) -> str:
    """ロット名 '4M_CAC001' → 'A' / '4M_CBC002' → 'B'"""
    alpha = re.sub(r"[^A-Za-z]", "", str(lot).split("_")[-1]).upper()
    for ch in alpha:
        if ch in ("A", "B"):
            return ch
    return "A"
