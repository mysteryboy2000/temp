import hashlib
import tempfile
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd
import streamlit as st
from streamlit_autorefresh import st_autorefresh

import predictor

# 日本標準時（JST, UTC+9・サマータイム無し）。
# tzdata に依存しない固定オフセットなので Docker でも確実に動く。
JST = timezone(timedelta(hours=9), "JST")

UPLOAD_DIR = Path(tempfile.gettempdir()) / "toner_uploads"

st.set_page_config(
    page_title="シェル投入モニター",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Streamlit デフォルト UI を非表示
st.markdown("""
<style>
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    .block-container { padding-top: 2rem; padding-bottom: 0; max-width: 900px; }
</style>
""", unsafe_allow_html=True)


@st.cache_resource(show_spinner="モデル・データを読み込み中...")
def _cached_context(csv_path: str, model_key: str, calibrate: bool):
    """CSV 全行の推論結果（モデル込み）。CSV ごとに 1 回だけ実行される。"""
    return predictor.build_context(model_key, csv_path=csv_path, calibrate=calibrate)


def _persist_upload(uploaded_file) -> Path:
    """アップロードされた CSV を一時ディレクトリに保存してパスを返す。

    ファイル名は品種・ライン表示（parse_file_meta）に使うためそのまま保持する。
    内容ハッシュをディレクトリ名にするので、同じファイルなら再アップロードでも
    キャッシュがそのまま効く。
    """
    data = uploaded_file.getvalue()
    digest = hashlib.sha256(data).hexdigest()[:16]
    safe_name = Path(uploaded_file.name).name or "uploaded.csv"

    dest_dir = UPLOAD_DIR / digest
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / safe_name
    if not dest.exists() or dest.read_bytes() != data:
        dest.write_bytes(data)
    return dest


def new_run(csv_path: Path):
    """CSV からランダムに 1 行選び、d50_jump を推論して投入までの残り時間を逆算。"""
    ctx = _cached_context(str(csv_path), predictor.DEFAULT_MODEL_KEY, predictor.CALIBRATE)
    idx = predictor.pick_random_row(ctx)

    row = ctx.df.loc[idx]
    t = ctx.timing.loc[idx]
    product, line = predictor.parse_file_meta(ctx.csv_path)

    # 逆算 Δt に DCS 時刻ズレ補正を足したものが投入までの残り時間
    total_sec = int(round(float(t["delta_t_min"]) * 60)) + predictor.CLOCK_OFFSET_SEC

    actual = pd.to_numeric(pd.Series([row.get(predictor.TARGET_COL)]), errors="coerce").iloc[0]
    dt_1 = t.get("dt_1")

    st.session_state.run = {
        "total_sec": max(1, total_sec),
        "delta_t_min": float(t["delta_t_min"]),
        "jump_pred": float(t["d50_jump_pred"]),
        "ridge": float(t["ridge_pred"]),
        "xgb": float(t["xgb_pred"]),
        "jump_actual": float(actual) if pd.notna(actual) else None,
        "target_shell_size": float(t["target_shell_size"]),
        "remaining_growth": float(t["remaining_growth"]),
        "d50_1": float(t["d50_1"]),
        "row_index": idx,
        "lot": str(row.get("toner_lot", "-")),
        "line": line,
        "product": product,
        "tank": predictor.parse_tank(row.get("toner_lot")),
        "dt_1_str": dt_1.strftime("%Y/%m/%d %H:%M") if isinstance(dt_1, pd.Timestamp) and pd.notna(dt_1) else "-",
        "csv_name": ctx.csv_path.name,
        "model_name": ctx.model_path.name,
        "n_ols": ctx.n_ols,
        "n_xgb": ctx.n_xgb,
        "mae": ctx.mae,
        "bias": ctx.bias,
        "calibrated": ctx.calibrated,
    }
    st.session_state.start_time = time.time()
    st.session_state.start_wall = datetime.now(JST)


def start_with_csv(csv_path: Path):
    """CSV を確定して倒計時画面へ遷移する。失敗した場合はアップロード画面に留まる。"""
    try:
        new_run(csv_path)
    except Exception as exc:
        st.session_state.pop("run", None)
        st.session_state.upload_error = f"{type(exc).__name__}: {exc}"
        return False
    st.session_state.csv_path = str(csv_path)
    st.session_state.pop("upload_error", None)
    st.session_state.pop("failed_csv", None)
    st.session_state.stage = "countdown"
    return True


def back_to_upload():
    st.session_state.stage = "upload"
    st.session_state.pop("run", None)
    st.session_state.pop("csv_path", None)
    st.session_state.pop("upload_error", None)
    st.session_state.pop("failed_csv", None)
    # file_uploader の key を変えてウィジェットをリセットする。
    # そうしないと前回のファイルが残ったままで、即座に倒計時へ戻ってしまう。
    st.session_state.uploader_seq = st.session_state.get("uploader_seq", 0) + 1


# =============================================================================
# 画面 1: CSV アップロード
# =============================================================================
def render_upload_page():
    st.markdown("""
    <div style="text-align:center;margin:1rem 0 2rem;">
        <div style="font-size:2.2rem;font-weight:600;letter-spacing:0.12em;color:#2c3e50;">
            シェル投入モニター
        </div>
        <div style="color:#888;font-size:1.05rem;margin-top:0.6rem;">
            バッチデータの CSV をドラッグ&ドロップしてください
        </div>
    </div>
    """, unsafe_allow_html=True)

    uploaded = st.file_uploader(
        "CSV ファイル",
        type=["csv"],
        accept_multiple_files=False,
        label_visibility="collapsed",
        key=f"csv_uploader_{st.session_state.get('uploader_seq', 0)}",
        help="d50_1 など学習時と同じカラムを含む CSV。ファイル名から品種・ラインを判定します",
    )

    # ドロップされた時点で推論して倒計時画面へ遷移する
    if uploaded is not None:
        csv_path = _persist_upload(uploaded)
        token = str(csv_path)
        if st.session_state.get("failed_csv") == token:
            # 同じファイルを再試行しても失敗するだけ（rerun ループになる）ので何もしない
            pass
        elif start_with_csv(csv_path):
            st.rerun()
        else:
            st.session_state.failed_csv = token

    # デモ用: リポジトリ同梱の data/*.csv を明示的に選んで使う（自動読み込みはしない）
    samples = sorted(predictor.DATA_DIR.glob("*.csv")) if predictor.DATA_DIR.exists() else []
    if samples:
        with st.expander("サンプルデータを使う（デモ用）"):
            names = [p.name for p in samples]
            choice = st.selectbox("data/ 内のCSV", names, label_visibility="collapsed")
            if st.button("このサンプルで開始", use_container_width=True):
                if start_with_csv(predictor.DATA_DIR / choice):
                    st.rerun()

    if err := st.session_state.get("upload_error"):
        st.error(f"このCSVでは推論できませんでした: {err}")


# =============================================================================
# 画面 2: 倒計時
# =============================================================================
def render_countdown_page():
    # 1秒ごとにリフレッシュ
    st_autorefresh(interval=1000, key="countdown")

    run = st.session_state.run
    csv_path = Path(st.session_state.csv_path)

    # --- 倒计时（逆算した残り時間を起点に、起動からの経過秒を引く）---
    total_seconds = run["total_sec"]
    elapsed_sec = int(time.time() - st.session_state.start_time)
    remaining_sec = max(0, total_seconds - elapsed_sec)

    remaining_min = remaining_sec // 60
    remaining_sec_part = remaining_sec % 60

    # 進捗バー充填率
    fill_pct = max(0.0, min(100.0, elapsed_sec / total_seconds * 100))
    empty_pct = 100.0 - fill_pct

    # 色ロジック（残り分数で緑→黄→赤）
    if remaining_min >= 15:
        accent    = "#27ae60"
        bg_light  = "#d5f5e3"
        bar_color = "#2ecc71"
    elif remaining_min >= 5:
        accent    = "#e67e22"
        bg_light  = "#fdebd0"
        bar_color = "#f39c12"
    else:
        accent    = "#c0392b"
        bg_light  = "#fadbd8"
        bar_color = "#e74c3c"

    # 静的フィールド
    line    = run["line"]
    tank    = run["tank"]
    product = run["product"]

    # 投入予定時刻（JST）= 起動時刻 + 逆算した残り時間。
    # total_seconds から求めることで、倒计时が 0 になる瞬間とこの時刻が必ず一致する。
    shell_dt = st.session_state.start_wall + timedelta(seconds=total_seconds)
    shell_time_str = shell_dt.strftime("%H:%M:%S")

    prev_time_str = st.session_state.start_wall.strftime("%H:%M:%S")
    prev_d50 = f"{run['d50_1']:.2f}"

    # 上部：ライン / 品種 / 槽バッジ
    if tank == "A":
        tank_a_style = f"background:{accent};color:white;padding:6px 18px;border-radius:6px;font-weight:bold;font-size:1.1rem;"
        tank_b_style =  "background:#ccc;color:#666;padding:6px 18px;border-radius:6px;font-weight:bold;font-size:1.1rem;"
    else:
        tank_a_style =  "background:#ccc;color:#666;padding:6px 18px;border-radius:6px;font-weight:bold;font-size:1.1rem;"
        tank_b_style = f"background:{accent};color:white;padding:6px 18px;border-radius:6px;font-weight:bold;font-size:1.1rem;"

    st.markdown(f"""
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;">
        <div style="font-size:1.3rem;line-height:1.8;">
            <span style="color:#666;">ライン：</span><strong>{line}</strong><br>
            <span style="color:#666;">品種　：</span><strong>{product}</strong>
        </div>
        <div style="display:flex;gap:10px;align-items:center;">
            <span style="{tank_a_style}">A槽</span>
            <span style="{tank_b_style}">B槽</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # 中央バナー
    st.markdown(f"""
    <div style="background:{bg_light};border-radius:16px;padding:3rem 2rem;text-align:center;margin-bottom:1.5rem;">
        <div style="color:{accent};font-size:2.5rem;font-weight:600;letter-spacing:0.15em;margin-bottom:0.5rem;">シェル投入</div>
        <div style="color:{accent};font-size:5.5rem;font-weight:bold;letter-spacing:0.05em;line-height:1.1;white-space:nowrap;font-variant-numeric:tabular-nums;">{shell_time_str}</div>
    </div>
    """, unsafe_allow_html=True)

    # 進捗バー + 残り時間
    border_radius_right = "10px" if fill_pct == 0 else "0 10px 10px 0"
    min_width = "0px" if fill_pct == 0 else "4px"
    st.markdown(f"""
    <div style="display:flex;align-items:center;gap:0;margin-bottom:0.8rem;height:52px;border-radius:10px;overflow:hidden;">
        <div style="flex:{fill_pct};background:{bar_color};height:100%;min-width:{min_width};border-radius:10px 0 0 10px;"></div>
        <div style="flex:{empty_pct};background:#ddd;height:100%;display:flex;align-items:center;justify-content:center;border-radius:{border_radius_right};">
            <span style="font-size:1.4rem;font-weight:bold;color:#444;padding-right:1rem;">
                あと<span style="font-size:2rem;font-weight:900;">{remaining_min}分{remaining_sec_part:02d}秒</span>
            </span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # 前回粒径（d50_1 = 逆算の起点となる測定値）
    st.markdown(f"""
    <div style="text-align:center;color:#666;font-size:1.1rem;margin-top:0.5rem;">
        前回：<strong>{prev_d50}µm</strong>　({prev_time_str})
    </div>
    """, unsafe_allow_html=True)

    # --- 逆算の内訳（デモ用フッター）---
    actual_txt = f"{run['jump_actual']:.2f}µm" if run["jump_actual"] is not None else "--"
    mae_txt = ""
    if run["mae"] is not None:
        mae_txt = f"<br>全行 MAE {run['mae']:.3f}µm　バイアス {run['bias']:+.3f}µm"
        mae_txt += "（補正ON）" if run["calibrated"] else "（未補正）"
    st.markdown(f"""
    <div style="text-align:center;color:#999;font-size:0.85rem;margin-top:1.2rem;line-height:1.7;">
        予測ジャンプ幅 {run['jump_pred']:.3f}µm
        (Ridge {run['ridge']:.3f} + XGB {run['xgb']:+.3f})　/　実測 {actual_txt}<br>
        狙い粒径 {predictor.TARGET_FINAL_SIZE} − {run['jump_pred']:.3f} = {run['target_shell_size']:.3f}µm　→　
        残り成長 {run['remaining_growth']:.3f}µm ÷ {predictor.GROWTH_RATE_UM_PER_MIN}µm/min =
        <strong>{run['delta_t_min']:.1f}分</strong>　(+{predictor.CLOCK_OFFSET_SEC}秒補正)<br>
        {run['csv_name']} row {run['row_index']}　lot {run['lot']}　d50_1測定 {run['dt_1_str']}<br>
        model {run['model_name']}　OLS {run['n_ols']}特徴量 / XGB {run['n_xgb']}特徴量
        {mae_txt}
    </div>
    """, unsafe_allow_html=True)

    col_retry, col_back = st.columns(2)
    with col_retry:
        if st.button("別のロットで再抽選", use_container_width=True):
            new_run(csv_path)
            st.rerun()
    with col_back:
        if st.button("別のCSVを読み込む", use_container_width=True):
            back_to_upload()
            st.rerun()

    if run["mae"] is not None and abs(run["bias"]) > 0.2:
        if run["calibrated"]:
            st.caption(
                f"ℹ️ このモデルの d50_jump 予測は CSV 実測に対し平均 {run['bias']:+.2f}µm のバイアスが"
                f"あるため、平均差のみを除去して表示しています（TONER_CALIB=0 で生の出力）。"
            )
        else:
            st.warning(
                f"⚠️ モデルの d50_jump 予測は CSV 実測に対して平均 {run['bias']:+.2f}µm ずれています"
                f"（MAE {run['mae']:.2f}µm ≒ タイミング誤差 ±{run['mae'] / predictor.GROWTH_RATE_UM_PER_MIN:.0f}分）。"
                "0.01µm/min で時間換算されるため、倒計時が実績（平均35分）から大きく外れます。"
            )


# =============================================================================
# ルーティング
# =============================================================================
if st.session_state.get("stage") == "countdown" and "run" in st.session_state:
    render_countdown_page()
else:
    st.session_state.stage = "upload"
    render_upload_page()
